---
title: "STEM Books & Science Experiment Books for Kids | Ages 6–10 | Little Promise Press"
description: "Discover our STEM books for kids with fun, hands-on science experiments. Perfect for ages 6–10, families, teachers, and bilingual English–Spanish learning."
keywords:
  - STEM books for kids
  - science experiment book
  - STEM for elementary school
  - science activities for kids
  - easy science experiments
slug: "books"
draft: false
---


# Our books

## Fun Science for Curious Minds

A collection of **30 simple experiments** using everyday materials
to learn science through play.

- Clear explanations written for kids
- Guidance notes for adults
- Safety tips on each activity

[View on Amazon](https://amzn.eu/d/gOPhgRc)

---

## Curious Minds: Fun Science Experiments

The full English edition, perfect for bilingual families and schools.

[View on Amazon](https://amzn.eu/d/8gOAr6d)
