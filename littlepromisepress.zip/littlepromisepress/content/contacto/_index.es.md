---
title: "Contacto | Little Promise Press"
section_tagline: "Hablemos"
section_subtitle: "Si eres madre, padre o profe, nos encantará escucharte"
description: "Ponte en contacto con Little Promise Press para colaboraciones, reseñas o uso de nuestros libros de ciencia en el aula."
---


Si quieres proponernos una colaboración, comentar nuestros libros
o preguntar por usos en el aula, puedes escribirnos a:

- 📧 **contacto@littlepromisepress.com**

