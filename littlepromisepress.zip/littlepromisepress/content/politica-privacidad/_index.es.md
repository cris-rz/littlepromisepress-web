---
title: "Política de privacidad"
slug: "politica-privacidad"
description: "Política de privacidad de Little Promise Press"
layout: "page"    # o "single", según cómo se llamen tus plantillas
---

En **Little Promise Press** respetamos tu privacidad y tratamos únicamente los datos estrictamente necesarios.

---

## 1. Responsable del tratamiento

**Responsable:** Little Promise Press  
**Email:** contacto@littlepromisepress.com  

Este sitio web es de carácter informativo y está alojado en GitHub Pages.

---

## 2. Datos que recogemos

### 2.1. Datos que nos proporcionas

Este sitio **no dispone de formularios**.  
Solo trataremos tus datos personales si te pones en contacto con nosotros por correo electrónico. En ese caso, utilizaremos tu dirección de email y los datos que incluyas en tu mensaje únicamente para responder a tu consulta.

### 2.2. Datos técnicos y de navegación

Al visitar la web, el proveedor de alojamiento (GitHub Pages) puede recopilar de forma automática ciertos datos técnicos de manera anonimizada o agregada, como:

- Dirección IP acortada o anonimizada  
- Tipo de navegador y sistema operativo  
- Páginas visitadas y tiempo de visita  

---

## 3. Finalidad y base legal

Los datos personales se utilizan con las siguientes finalidades:

- **Responder a consultas enviadas por email.**  
  - Base legal: tu consentimiento y nuestro interés legítimo en responder a solicitudes de información.

- **Garantizar funcionamiento y seguridad del sitio**
